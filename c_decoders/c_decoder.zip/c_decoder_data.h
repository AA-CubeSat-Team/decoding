/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: c_decoder_data.h
 *
 * MATLAB Coder version            : 5.1
 * C/C++ source code generated on  : 30-Mar-2022 22:13:07
 */

#ifndef C_DECODER_DATA_H
#define C_DECODER_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include "omp.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern omp_nest_lock_t emlrtNestLockGlobal;
extern boolean_T isInitialized_c_decoder;

#endif

/*
 * File trailer for c_decoder_data.h
 *
 * [EOF]
 */
