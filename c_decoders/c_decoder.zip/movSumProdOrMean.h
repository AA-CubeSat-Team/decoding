/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: movSumProdOrMean.h
 *
 * MATLAB Coder version            : 5.1
 * C/C++ source code generated on  : 30-Mar-2022 22:13:07
 */

#ifndef MOVSUMPRODORMEAN_H
#define MOVSUMPRODORMEAN_H

/* Include Files */
#include "rtwtypes.h"
#include "omp.h"
#include <stddef.h>
#include <stdlib.h>
#ifdef __cplusplus

extern "C" {

#endif

  /* Function Declarations */
  void vmovfun(const double x[512989], double y[512989]);

#ifdef __cplusplus

}
#endif
#endif

/*
 * File trailer for movSumProdOrMean.h
 *
 * [EOF]
 */
